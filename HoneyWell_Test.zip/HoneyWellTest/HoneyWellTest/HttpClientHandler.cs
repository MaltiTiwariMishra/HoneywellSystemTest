﻿using System;

namespace HoneyWellTest
{
    internal class HttpClientHandler
    {
        public bool UseDefaultCredentials { get; set; }
    }
}