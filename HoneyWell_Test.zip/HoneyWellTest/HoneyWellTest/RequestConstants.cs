﻿using System.Net;

namespace HoneyWellTest
{
    internal class RequestConstants
    {
        public static HttpRequestHeader UserAgent { get; internal set; }
        public static string UserAgentValue { get; internal set; }
    }
}