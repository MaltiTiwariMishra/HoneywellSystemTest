﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static System.Net.WebRequestMethods;

namespace HoneyWellTest
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var TempValue = "";
            string Url = "";
            //On Page load save the generated Random Number
            string Temperature = RandomNumber();
             Url = "Http://localhost:3267/saveTemperature?Temperature=Temperature";
            GetReleases(Url);

            //Get The temperature value from DB
             Url = "Http://localhost:3267/getTemperature";
            TempValue= GetReleases(Url);

            foreach (var control in mydiv.Controls)
            {
                Label label = control as Label;
                if (label != null)

                {
                    if (TempValue == "")
                    {
                        label.Text = "32";
                    }
                    else
                    label.Text = TempValue;
                }
            }

        }


        //// Generate Random Number
        public string RandomNumber()
        {
            var rnd = new Random(DateTime.Now.Millisecond);
            string Number = rnd.Next(24, 56).ToString();
            return Number;
        }


      
       public string GetRelease(string url)
        {
            var request = (HttpWebRequest)WebRequest.Create(url);

            request.Method = "GET";
            object RequestConstants = null;
           request.UserAgent = RequestConstants.ToString();
            request.AutomaticDecompression = DecompressionMethods.Deflate | DecompressionMethods.GZip;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            var content = string.Empty;

            using (var response = (HttpWebResponse)request.GetResponse())
            {
                using (var stream = response.GetResponseStream())
                {
                    using (var sr = new StreamReader(stream))
                    {
                        content = sr.ReadToEnd();
                    }
                }
            }

            return content;
        }


      
        public string GetReleases(string url)
        {
            var client = new WebClient();
            client.Headers.Add(RequestConstants.UserAgent, RequestConstants.UserAgentValue);

            var response = client.DownloadString(url);

            return response;
        }




    }
}