﻿using System;
using System.Data;
using Resource.eForms.DAL;
using Resource.eForms.Utilities;
using System.Configuration;
using Resource.eForms.Entities;
using System.Net;
using System.Web;
using System.Net.Mail;



namespace Resource.eForms.Business
{
    public class CommonBal
    {
        
        Common objDAL = new Common();
        private static string _password = ConfigurationManager.AppSettings["EncryptPassword"].ToString();
        private static string _saltValue = ConfigurationManager.AppSettings["EncryptSaltValue"].ToString();
        private static string _initializationVector = ConfigurationManager.AppSettings["EncryptKey"].ToString();
        private static Encryption.EncryptDecrypt.EncryptionAlgorythm _algorythm = Encryption.EncryptDecrypt.EncryptionAlgorythm.SHA1;
        private static Encryption.EncryptDecrypt.PasswordIterations _iterations = Encryption.EncryptDecrypt.PasswordIterations.One1;
        private static Encryption.EncryptDecrypt.EncryptionKeySize _keySize = Encryption.EncryptDecrypt.EncryptionKeySize.OneTwentyEight128;

        public CommonBal()

        {
           
        }

        public class LoginBAL
        {
          public string LoginCredential(string username, string password)
            {
                return "Login Success";
            }

        }
        public DataSet UserDetails()
        {
            return objDAL.GetConnection();
        }
        public int IsExpiredORIsLocked(string UserName)
        {
            return objDAL.IsExpiredORIsLocked(UserName);
        }

        public bool TempPassword(string username, string sitePath, string action)
        {
            User objResetPassword = new User();
            bool Reset;

            Utilities.Utilities objutilities = new Utilities.Utilities();
            
            try
            {
                objResetPassword = objDAL.ResetPassword(username);

                if (!string.IsNullOrEmpty(objResetPassword.TempPassword))
                {

                    // SENDING THE TEMP PASSWORD TO THE USER
                    Reset = objutilities.SendEmail(objResetPassword.EmailAddress, objResetPassword.UserName, objResetPassword.TempPassword, sitePath, action);
                    string tempPwd = objResetPassword.TempPassword;
                    tempPwd = Encryption.EncryptDecrypt.Encrypt(tempPwd.ToString(), _password, _saltValue, _algorythm, _iterations, _initializationVector, _keySize);
                    objDAL.UpdateEncyptedTempPwd(tempPwd, username);
                }
                else
                {
                    Reset = false;
                }

                return Reset;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetRole(string RoleName)
        {
            return objDAL.GetRole(RoleName);
        }
    }
}