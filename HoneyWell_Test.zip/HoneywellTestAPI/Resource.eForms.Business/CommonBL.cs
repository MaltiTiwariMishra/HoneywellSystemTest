﻿using System;

using System.Data;
using HoneywellDAL;



namespace Resource.eForms.Business
{
    public class CommonBL
    {
        readonly CommonDAL _objCommonDal = null;
        public CommonBL()
        {
            _objCommonDal = new CommonDAL();
        }

        public DataTable SaveTemperature(string Temperature)
        {
            return _objCommonDal.SaveTemperature(Temperature);
        }
        public DataTable GetTemperature()
        {
            return _objCommonDal.GetTemperature();
        }


    }
}