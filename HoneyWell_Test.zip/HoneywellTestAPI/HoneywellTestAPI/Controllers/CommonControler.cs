﻿using System.Net;
using System.Web.Http;
using HoneywellBAL;
using System.Data;
using System.IO;
using System;


namespace HoneywellTestAPI.Controllers
{
    [RoutePrefix("api/common")]
    public class CommonControler
    {

        readonly commonbl _objcommonbl;

        public CommonController()
        {
            
            _objCommonBl = new CommonBL();
        }


        /// <summary>
        /// Save the Temperature
        /// </summary>
        /// <param name="TempValue"></param>
        /// <returns></returns>
        [HttpGet]
        [AllowAnonymous]
        [Route("saveTemperature")]
        public IHttpActionResult SaveTemperature(string Temperature)
        {
            var objTemp = _objCommonBl.SaveTemperature(Temperature);

            return Ok(objTemp);
        }


        /// <summary>
        /// GetTemperature value
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        [HttpGet]
        [AllowAnonymous]
        [Route("getTemperature")]
        public IHttpActionResult GetTemperature()
        {
            var dtTemperature = _objCommonBl.GetTemperature();

            return Ok(dtTemperature);

        }



    }
}