﻿using Microsoft.Owin.Security.OAuth;
using System.Security.Claims;
using System.Threading.Tasks;
using Resource.eForms.Entities;
using Resource.eForms.Business;
using System;
using System.Threading;
using System.Collections.Generic;

using System.Security.Principal;
namespace HoneywellTestAPI
{
    public class AuthorizationServerProvider
    {
        public override async Task ValidateClientAuthentication(OAuthValidateClientAuthenticationContext context)
        {
            context.Validated(); // 
        }
    }
}