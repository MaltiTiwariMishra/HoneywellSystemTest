﻿using System;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data;
using System.Data.Common;

namespace Resource.eForms.DAL
{
    public class ConnectionHelper
    {

        public static Database GetConnection()
        {
            DatabaseProviderFactory factory = new DatabaseProviderFactory();

            return factory.Create(DatabaseConstants.ConnectionString);
        }

        public static Database GetConnection(string clientName)
        {
            return new GenericDatabase(ConnectionString(), DbProviderFactories.GetFactory("System.Data.SqlClient"));
        }

        private static string ConnectionString()
        {
            
               string connectionString;
            try
            {
                connectionString =
                       "Server=BDC11-L-6440MR1;Database=eForms_Metadata_DB;User ID=sa;Password=Acc1234$$";

               }
            catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    
                }
                return connectionString;
            }
        
    }
}
