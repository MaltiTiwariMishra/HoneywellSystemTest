﻿namespace Resource.eForms.DAL
{
    public static class DatabaseConstants
    {
        #region Con String
        public static string ConnectionString = "HoneywellConnectionString";
        #endregion

        #region Store Procs
        public static string SaveTemperature = "InsertTempDetails";
        public static string GetTemperature = "GetTempDetails";



        #endregion


    }
}

