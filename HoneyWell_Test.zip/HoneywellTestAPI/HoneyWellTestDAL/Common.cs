﻿using System;
using System.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using Resource.eForms.Entities;

namespace Resource.eForms.DAL
{
    public class Common
    {
        private string _connectionString = string.Empty;
        private string _client = string.Empty;
        private Database Client = null;
        DatabaseProviderFactory dbFactory = new DatabaseProviderFactory();
       
        public Common()
        {
            Client = dbFactory.CreateDefault();
        }

        public DataSet GetConnection()
        {
            using (DbCommand cmd = Client.GetStoredProcCommand("sp_Admin_Testing"))
            {
                return Client.ExecuteDataSet(cmd);
            }

        }

        public int IsExpiredORIsLocked(string UserName)
        {
            int result;
            try
            {

                DbCommand cmdIsLocked = Client.GetStoredProcCommand("sp_eForms_Common_IsExpiredORIsLocked");
                Client.AddInParameter(cmdIsLocked, "UserName", DbType.String, UserName);
                Client.AddOutParameter(cmdIsLocked, "Result", DbType.Int32, 0);
                result = int.Parse(Client.ExecuteScalar(cmdIsLocked).ToString());
                return result;
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public User ResetPassword(string UserName)
        {
            User objResetPassword = new User();
            DbCommand cmdResetPswrd = Client.GetStoredProcCommand("sp_eForms_Common_spResetPassword");
            Client.AddInParameter(cmdResetPswrd, "UserName", DbType.String, UserName);
            using (IDataReader drResetPassword = Client.ExecuteReader(cmdResetPswrd))
            {
                while (drResetPassword.Read())
                {

                    objResetPassword.UserID = int.Parse(drResetPassword["UserID"].ToString());
                    objResetPassword.UserName = Convert.ToString(drResetPassword["UserName"]);
                    objResetPassword.EmailAddress = Convert.ToString(drResetPassword["EmailAddress"]);
                    objResetPassword.TempPassword = Convert.ToString(drResetPassword["ResetPassword"]);
                    objResetPassword.LastPwdChangedOn = Convert.ToDateTime(drResetPassword["LastPwdChangedOn"]);

                }
            }
            return objResetPassword;
        }
             public void UpdateEncyptedTempPwd(string tempPwd, string username)
             { 
                DbCommand cmdUpdateTemPassword = Client.GetStoredProcCommand("sp_eForms_Common_UpdateEncyptedTempPwd");
                Client.AddInParameter(cmdUpdateTemPassword, "TempPassword", DbType.String, tempPwd);
                Client.AddInParameter(cmdUpdateTemPassword, "username", DbType.String, username);
                Client.ExecuteNonQuery(cmdUpdateTemPassword);
             }
       
        public DataTable GetRole(string RoleName)
        {
            using (DbCommand cmdGetRole = Client.GetStoredProcCommand("sp_eForms_getRoles"))
            {
                Client.AddInParameter(cmdGetRole, "RoleName", DbType.String, RoleName);
                return Client.ExecuteDataSet(cmdGetRole).Tables[0];
            }
        }

    }




}

