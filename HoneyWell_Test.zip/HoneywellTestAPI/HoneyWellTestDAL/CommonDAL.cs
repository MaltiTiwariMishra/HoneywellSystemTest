﻿using System;
using System.Data;

namespace Resource.eForms.DAL
{
    public class CommonDAL
    {


        /// <summary>
        ///Save Temperature
        /// </summary>
        /// <param name="Temperature"></param>
        /// <returns></returns>
        public DataTable SaveTemperature(string Temperature)
        {
            var objCon = ConnectionHelper.GetConnection();
            using (var objCmd = objCon.GetStoredProcCommand(DatabaseConstants.SaveTemperature))
            {
            
                objCon.AddInParameter(objCmd, "TempValue", DbType.String, Temperature);
                objCmd.CommandTimeout = 300;
                return objCon.ExecuteDataSet(objCmd).Tables[0];
            }
        }

        /// <summary>
        ///get Temperature
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public DataTable GetTemperature()
        {
            var objCon = ConnectionHelper.GetConnection();
            using (var objCmd = objCon.GetStoredProcCommand(DatabaseConstants.GetTemperature))
            {
                objCmd.CommandTimeout = 300;
                return objCon.ExecuteDataSet(objCmd).Tables[0];
            }
        }


    }
}




