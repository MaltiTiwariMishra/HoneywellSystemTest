﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Resource.eForms.DAL
{
    
        public class TempEntity
        {
            public String Temperature { get; set; }
            
        }
    
}
